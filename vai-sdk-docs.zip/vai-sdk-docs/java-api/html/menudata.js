var menudata={children:[
{text:"首页",url:"index.html"},
{text:"类",url:"annotated.html",children:[
{text:"类列表",url:"annotated.html"},
{text:"类索引",url:"classes.html"},
{text:"类成员",url:"functions.html",children:[
{text:"全部",url:"functions.html"},
{text:"函数",url:"functions_func.html"},
{text:"变量",url:"functions_vars.html"}]}]}]}
