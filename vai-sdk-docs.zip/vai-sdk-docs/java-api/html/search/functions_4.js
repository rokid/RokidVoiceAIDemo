var searchData=
[
  ['startvoice',['startVoice',['../classcom_1_1rokid_1_1voiceai_1_1VoiceAI.html#a768bf42b1f44939b597e44d4b7765bfa',1,'com::rokid::voiceai::VoiceAI']]],
  ['stop',['stop',['../classcom_1_1rokid_1_1voiceai_1_1VoiceAI.html#a9de1f1f46615ad3762510924ba8ac91c',1,'com::rokid::voiceai::VoiceAI']]]
];
