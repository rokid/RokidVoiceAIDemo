var searchData=
[
  ['onaccept',['onAccept',['../interfacecom_1_1rokid_1_1voiceai_1_1VoiceCallback.html#a8fa300463cec1bda4541b6e248fbf128',1,'com::rokid::voiceai::VoiceCallback']]],
  ['onasr',['onAsr',['../interfacecom_1_1rokid_1_1voiceai_1_1VoiceCallback.html#ab6235833734bbbce035ee27344b5760a',1,'com::rokid::voiceai::VoiceCallback']]],
  ['onerror',['onError',['../interfacecom_1_1rokid_1_1voiceai_1_1VoiceCallback.html#ac83a98258c31fbbfc9e4f76d1dd8dbbc',1,'com::rokid::voiceai::VoiceCallback']]],
  ['onresult',['onResult',['../interfacecom_1_1rokid_1_1voiceai_1_1VoiceCallback.html#a26fc4304c3830393ed2e4db556491a76',1,'com::rokid::voiceai::VoiceCallback']]]
];
