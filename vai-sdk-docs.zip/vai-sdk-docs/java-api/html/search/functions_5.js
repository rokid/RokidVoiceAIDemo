var searchData=
[
  ['texttospeech',['textToSpeech',['../classcom_1_1rokid_1_1voiceai_1_1VoiceAI.html#a5c1034de38ddd9ad3556850e65dd9ed9',1,'com::rokid::voiceai::VoiceAI']]]
];
