var indexSectionsWithContent =
{
  0: "adeopstvw",
  1: "astv",
  2: "deopstw",
  3: "ad"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "全部",
  1: "类",
  2: "函数",
  3: "变量"
};

