var searchData=
[
  ['session',['Session',['../classcom_1_1rokid_1_1voiceai_1_1Session.html',1,'com::rokid::voiceai']]],
  ['setactioncallback',['setActionCallback',['../classcom_1_1rokid_1_1voiceai_1_1VoiceAI_1_1Builder.html#a11091a5679e53abcbfcf043cb9cbab69',1,'com::rokid::voiceai::VoiceAI::Builder']]],
  ['setauthinfo',['setAuthInfo',['../classcom_1_1rokid_1_1voiceai_1_1VoiceAI_1_1Builder.html#a0ae8d6d4063648760a03c35111e30f80',1,'com::rokid::voiceai::VoiceAI::Builder']]],
  ['setdeclaimer',['setDeclaimer',['../classcom_1_1rokid_1_1voiceai_1_1VoiceAI_1_1Builder.html#a119b756ca88c52ee25acdd3889672ad0',1,'com::rokid::voiceai::VoiceAI::Builder']]],
  ['setreporturi',['setReportUri',['../classcom_1_1rokid_1_1voiceai_1_1VoiceAI_1_1Builder.html#ab511f52b822206dfec42a3fd9ad15ca1',1,'com::rokid::voiceai::VoiceAI::Builder']]],
  ['setspeechcodec',['setSpeechCodec',['../classcom_1_1rokid_1_1voiceai_1_1VoiceAI_1_1Builder.html#af52248325c252946e86d55b351cef3ed',1,'com::rokid::voiceai::VoiceAI::Builder']]],
  ['setspeechuri',['setSpeechUri',['../classcom_1_1rokid_1_1voiceai_1_1VoiceAI_1_1Builder.html#aeae05701decde8391ac77002ac381b1a',1,'com::rokid::voiceai::VoiceAI::Builder']]],
  ['setttscodec',['setTtsCodec',['../classcom_1_1rokid_1_1voiceai_1_1VoiceAI_1_1Builder.html#afac5f71576e40a636de9e8d100c95419',1,'com::rokid::voiceai::VoiceAI::Builder']]],
  ['setttssamplerate',['setTtsSampleRate',['../classcom_1_1rokid_1_1voiceai_1_1VoiceAI_1_1Builder.html#a9728864ef20e1d8dc6b99a61ec83b74a',1,'com::rokid::voiceai::VoiceAI::Builder']]],
  ['setvoicecallback',['setVoiceCallback',['../classcom_1_1rokid_1_1voiceai_1_1VoiceAI_1_1Builder.html#a8a78299adef4d0be8ba15d32402dd991',1,'com::rokid::voiceai::VoiceAI::Builder']]],
  ['startvoice',['startVoice',['../classcom_1_1rokid_1_1voiceai_1_1VoiceAI.html#a768bf42b1f44939b597e44d4b7765bfa',1,'com::rokid::voiceai::VoiceAI']]],
  ['stop',['stop',['../classcom_1_1rokid_1_1voiceai_1_1VoiceAI.html#a9de1f1f46615ad3762510924ba8ac91c',1,'com::rokid::voiceai::VoiceAI']]]
];
