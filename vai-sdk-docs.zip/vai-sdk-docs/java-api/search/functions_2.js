var searchData=
[
  ['getappid',['getAppId',['../classcom_1_1rokid_1_1voiceai_1_1Session.html#ab47240ea9d56b5fae799aaae7facd206',1,'com::rokid::voiceai::Session']]]
];
