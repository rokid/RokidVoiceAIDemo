var searchData=
[
  ['texttospeech',['textToSpeech',['../classcom_1_1rokid_1_1voiceai_1_1VoiceAI.html#a5c1034de38ddd9ad3556850e65dd9ed9',1,'com::rokid::voiceai::VoiceAI']]],
  ['trigger',['trigger',['../classcom_1_1rokid_1_1voiceai_1_1VoiceOptions.html#a1449f45dd812d2b5d5d7e925a279c58e',1,'com::rokid::voiceai::VoiceOptions']]],
  ['triggerconfirm',['triggerConfirm',['../classcom_1_1rokid_1_1voiceai_1_1VoiceOptions.html#ab4f74a55ab1df557fd25b0d4922ca7b2',1,'com::rokid::voiceai::VoiceOptions']]],
  ['triggerlength',['triggerLength',['../classcom_1_1rokid_1_1voiceai_1_1VoiceOptions.html#a10a78409d84e8803ded958dd0d52b2de',1,'com::rokid::voiceai::VoiceOptions']]],
  ['triggerstart',['triggerStart',['../classcom_1_1rokid_1_1voiceai_1_1VoiceOptions.html#a1c13171e2097599d7f241fb601c78ec6',1,'com::rokid::voiceai::VoiceOptions']]],
  ['ttscallback',['TtsCallback',['../interfacecom_1_1rokid_1_1voiceai_1_1TtsCallback.html',1,'com::rokid::voiceai']]],
  ['ttsplayfinish',['ttsPlayFinish',['../classcom_1_1rokid_1_1voiceai_1_1Session.html#a66dfcde2dbab88045148c1f8b4a9f574',1,'com::rokid::voiceai::Session']]]
];
