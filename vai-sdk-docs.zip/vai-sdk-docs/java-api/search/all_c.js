var searchData=
[
  ['voiceai',['VoiceAI',['../classcom_1_1rokid_1_1voiceai_1_1VoiceAI.html',1,'com::rokid::voiceai']]],
  ['voicecallback',['VoiceCallback',['../interfacecom_1_1rokid_1_1voiceai_1_1VoiceCallback.html',1,'com::rokid::voiceai']]],
  ['voiceoptions',['VoiceOptions',['../classcom_1_1rokid_1_1voiceai_1_1VoiceOptions.html',1,'com::rokid::voiceai']]]
];
