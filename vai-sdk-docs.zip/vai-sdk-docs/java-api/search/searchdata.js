var indexSectionsWithContent =
{
  0: "abdegimnopstvw",
  1: "abstv",
  2: "degimnopstw",
  3: "adpt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "全部",
  1: "类",
  2: "函数",
  3: "变量"
};

