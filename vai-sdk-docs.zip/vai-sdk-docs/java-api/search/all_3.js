var searchData=
[
  ['endvoice',['endVoice',['../classcom_1_1rokid_1_1voiceai_1_1VoiceAI.html#a77333a5293bb28c01a34180e468fa181',1,'com::rokid::voiceai::VoiceAI']]]
];
