var searchData=
[
  ['audio_5fcodec',['AUDIO_CODEC',['../classrokid_1_1VoiceAI.html#a675f02297139938374912b91cd6b0880a3aeefce4011b3e89c26b629a3b0f77e9',1,'rokid::VoiceAI']]],
  ['authinfo',['AUTHINFO',['../classrokid_1_1VoiceAI.html#a675f02297139938374912b91cd6b0880a71cc8ff2826a954f31f2fc24735a666f',1,'rokid::VoiceAI']]]
];
