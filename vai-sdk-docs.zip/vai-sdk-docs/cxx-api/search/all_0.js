var searchData=
[
  ['actioncallback',['ActionCallback',['../classrokid_1_1VoiceAI_1_1ActionCallback.html',1,'rokid::VoiceAI']]],
  ['actionfilter',['ActionFilter',['../voice-ai_8h.html#a56b6140bc000895fdfcc03cab1f540e0',1,'rokid']]],
  ['audio_5fcodec',['AUDIO_CODEC',['../classrokid_1_1VoiceAI.html#a675f02297139938374912b91cd6b0880a3aeefce4011b3e89c26b629a3b0f77e9',1,'rokid::VoiceAI']]],
  ['audiocodec',['AudioCodec',['../classrokid_1_1VoiceAI.html#aee279c0468933a14efda7bd2787a8f38',1,'rokid::VoiceAI']]],
  ['authinfo',['AUTHINFO',['../classrokid_1_1VoiceAI.html#a675f02297139938374912b91cd6b0880a71cc8ff2826a954f31f2fc24735a666f',1,'rokid::VoiceAI']]],
  ['available',['available',['../classrokid_1_1TtsStream.html#ab644092b94277b76d4e09e3003a78dea',1,'rokid::TtsStream']]]
];
