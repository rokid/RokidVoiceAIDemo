var searchData=
[
  ['opu',['OPU',['../classrokid_1_1VoiceAI.html#aee279c0468933a14efda7bd2787a8f38af8d68da46570d175f59ed38ea191ada1',1,'rokid::VoiceAI']]],
  ['opu2',['OPU2',['../classrokid_1_1VoiceAI.html#aee279c0468933a14efda7bd2787a8f38a59f15baeec1d8638eb123a0cc9c7fcf9',1,'rokid::VoiceAI']]]
];
