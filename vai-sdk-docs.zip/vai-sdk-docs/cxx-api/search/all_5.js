var searchData=
[
  ['intermedia_5fasr',['INTERMEDIA_ASR',['../classrokid_1_1VoiceAI.html#a675f02297139938374912b91cd6b0880a3a78554351b704350c60e3259f50230a',1,'rokid::VoiceAI']]],
  ['isactive',['isActive',['../classrokid_1_1VoiceAI_1_1Session.html#a43a530ff1682efbab03ef5ce999e5d68',1,'rokid::VoiceAI::Session']]],
  ['isnative',['isNative',['../classrokid_1_1VoiceAI_1_1Session.html#a1e512ebfda60e3a55089e8ddb2650d8e',1,'rokid::VoiceAI::Session']]]
];
