var searchData=
[
  ['speech_5furi',['SPEECH_URI',['../classrokid_1_1VoiceAI.html#a675f02297139938374912b91cd6b0880a58d6c7ca6a32599860f9b20b53a84db0',1,'rokid::VoiceAI']]]
];
