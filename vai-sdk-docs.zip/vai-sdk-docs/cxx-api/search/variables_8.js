var searchData=
[
  ['trigger',['trigger',['../classrokid_1_1VoiceAI_1_1VoiceOptions.html#a2389392bf1c4eb95f80295f752578494',1,'rokid::VoiceAI::VoiceOptions']]],
  ['triggerconfirm',['triggerConfirm',['../classrokid_1_1VoiceAI_1_1VoiceOptions.html#aacec7a8ceb69f3a2d6658c738308ca4b',1,'rokid::VoiceAI::VoiceOptions']]],
  ['triggerlength',['triggerLength',['../classrokid_1_1VoiceAI_1_1VoiceOptions.html#aeff7257d6df96bea4a19129d96397a14',1,'rokid::VoiceAI::VoiceOptions']]],
  ['triggerstart',['triggerStart',['../classrokid_1_1VoiceAI_1_1VoiceOptions.html#a0c0c617f46ddaecbca4d53d341c44c26',1,'rokid::VoiceAI::VoiceOptions']]],
  ['ttsplayfinish',['ttsPlayFinish',['../classrokid_1_1VoiceAI_1_1Session.html#aadfca099cc55330e31a721631f6aa9c3',1,'rokid::VoiceAI::Session']]]
];
