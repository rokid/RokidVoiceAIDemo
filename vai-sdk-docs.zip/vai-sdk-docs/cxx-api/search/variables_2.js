var searchData=
[
  ['mediaplayfinish',['mediaPlayFinish',['../classrokid_1_1VoiceAI_1_1Session.html#aabfe0a93407baff2b5af4cf95364b06a',1,'rokid::VoiceAI::Session']]]
];
