var searchData=
[
  ['tts_5fcodec',['TTS_CODEC',['../classrokid_1_1VoiceAI.html#a675f02297139938374912b91cd6b0880a8638e93b1561908bd42f00741ff6a3c8',1,'rokid::VoiceAI']]],
  ['tts_5fdeclaimer',['TTS_DECLAIMER',['../classrokid_1_1VoiceAI.html#a675f02297139938374912b91cd6b0880a19f081455aa2767f7f941c48416652e6',1,'rokid::VoiceAI']]],
  ['tts_5fsamplerate',['TTS_SAMPLERATE',['../classrokid_1_1VoiceAI.html#a675f02297139938374912b91cd6b0880ab04fc99e8df3945627ec2de090695c4f',1,'rokid::VoiceAI']]]
];
