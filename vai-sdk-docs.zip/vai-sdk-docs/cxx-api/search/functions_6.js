var searchData=
[
  ['putaction',['putAction',['../classrokid_1_1VoiceAI.html#a13fa5b2c2e3cb00306b7dbc441d4b0d0',1,'rokid::VoiceAI']]],
  ['putasr',['putAsr',['../classrokid_1_1VoiceAI.html#a743791d8f0b00865e04d95607e4c4c61',1,'rokid::VoiceAI']]]
];
