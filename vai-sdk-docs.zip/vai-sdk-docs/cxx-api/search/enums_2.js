var searchData=
[
  ['option',['Option',['../classrokid_1_1VoiceAI.html#a675f02297139938374912b91cd6b0880',1,'rokid::VoiceAI']]]
];
