var searchData=
[
  ['voiceai',['VoiceAI',['../classrokid_1_1VoiceAI.html',1,'rokid']]],
  ['voicecallback',['VoiceCallback',['../classrokid_1_1VoiceAI_1_1VoiceCallback.html',1,'rokid::VoiceAI']]],
  ['voiceoptions',['VoiceOptions',['../classrokid_1_1VoiceAI_1_1VoiceOptions.html',1,'rokid::VoiceAI']]]
];
