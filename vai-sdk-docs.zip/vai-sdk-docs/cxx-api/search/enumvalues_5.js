var searchData=
[
  ['pcm',['PCM',['../classrokid_1_1VoiceAI.html#aee279c0468933a14efda7bd2787a8f38a1088fbc901dc88b6c18085220cc33de9',1,'rokid::VoiceAI']]]
];
