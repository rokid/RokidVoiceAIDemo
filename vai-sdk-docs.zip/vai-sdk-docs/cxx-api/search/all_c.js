var searchData=
[
  ['texttospeech',['textToSpeech',['../classrokid_1_1VoiceAI.html#a920b34e2107dfc75c542609ad6fbcb48',1,'rokid::VoiceAI']]],
  ['trigger',['trigger',['../classrokid_1_1VoiceAI_1_1VoiceOptions.html#a2389392bf1c4eb95f80295f752578494',1,'rokid::VoiceAI::VoiceOptions']]],
  ['triggerconfirm',['triggerConfirm',['../classrokid_1_1VoiceAI_1_1VoiceOptions.html#aacec7a8ceb69f3a2d6658c738308ca4b',1,'rokid::VoiceAI::VoiceOptions']]],
  ['triggerlength',['triggerLength',['../classrokid_1_1VoiceAI_1_1VoiceOptions.html#aeff7257d6df96bea4a19129d96397a14',1,'rokid::VoiceAI::VoiceOptions']]],
  ['triggerstart',['triggerStart',['../classrokid_1_1VoiceAI_1_1VoiceOptions.html#a0c0c617f46ddaecbca4d53d341c44c26',1,'rokid::VoiceAI::VoiceOptions']]],
  ['tts_5fcodec',['TTS_CODEC',['../classrokid_1_1VoiceAI.html#a675f02297139938374912b91cd6b0880a8638e93b1561908bd42f00741ff6a3c8',1,'rokid::VoiceAI']]],
  ['tts_5fdeclaimer',['TTS_DECLAIMER',['../classrokid_1_1VoiceAI.html#a675f02297139938374912b91cd6b0880a19f081455aa2767f7f941c48416652e6',1,'rokid::VoiceAI']]],
  ['tts_5fsamplerate',['TTS_SAMPLERATE',['../classrokid_1_1VoiceAI.html#a675f02297139938374912b91cd6b0880ab04fc99e8df3945627ec2de090695c4f',1,'rokid::VoiceAI']]],
  ['ttsplayfinish',['ttsPlayFinish',['../classrokid_1_1VoiceAI_1_1Session.html#aadfca099cc55330e31a721631f6aa9c3',1,'rokid::VoiceAI::Session']]],
  ['ttsstream',['TtsStream',['../classrokid_1_1TtsStream.html',1,'rokid']]]
];
