var searchData=
[
  ['config',['config',['../classrokid_1_1VoiceAI.html#ad926c5844dfda1ca0c82d63b3eaefee1',1,'rokid::VoiceAI']]]
];
