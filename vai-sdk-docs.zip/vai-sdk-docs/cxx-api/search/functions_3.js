var searchData=
[
  ['geterror',['getError',['../classrokid_1_1TtsStream.html#a3041fc81ae4a7477dbec1668dcd3f254',1,'rokid::TtsStream']]]
];
