var searchData=
[
  ['power',['power',['../classrokid_1_1VoiceAI_1_1VoiceOptions.html#a6e3cc7c7ada7cadee3800f333265d2ec',1,'rokid::VoiceAI::VoiceOptions']]]
];
