var searchData=
[
  ['nativeexit',['nativeExit',['../classrokid_1_1VoiceAI_1_1Session.html#afe2bd48101e2fa463560d8f87fa5bb55',1,'rokid::VoiceAI::Session']]]
];
