var searchData=
[
  ['voice_2dai_2eh',['voice-ai.h',['../voice-ai_8h.html',1,'']]],
  ['voiceai',['VoiceAI',['../classrokid_1_1VoiceAI.html',1,'rokid']]],
  ['voicecallback',['VoiceCallback',['../classrokid_1_1VoiceAI_1_1VoiceCallback.html',1,'rokid::VoiceAI']]],
  ['voiceoptions',['VoiceOptions',['../classrokid_1_1VoiceAI_1_1VoiceOptions.html',1,'rokid::VoiceAI']]]
];
