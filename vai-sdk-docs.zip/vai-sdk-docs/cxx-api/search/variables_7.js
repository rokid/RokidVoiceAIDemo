var searchData=
[
  ['samplerate',['sampleRate',['../classrokid_1_1TtsOptions.html#af8879b8d2242665ba994941ba3a3da3c',1,'rokid::TtsOptions']]]
];
