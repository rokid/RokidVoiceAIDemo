var indexSectionsWithContent =
{
  0: "acdegimnoprstvw",
  1: "astv",
  2: "v",
  3: "acegnoprstw",
  4: "gimnpt",
  5: "a",
  6: "ados",
  7: "acimoprst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues"
};

var indexSectionLabels =
{
  0: "全部",
  1: "类",
  2: "文件",
  3: "函数",
  4: "变量",
  5: "类型定义",
  6: "枚举",
  7: "枚举值"
};

