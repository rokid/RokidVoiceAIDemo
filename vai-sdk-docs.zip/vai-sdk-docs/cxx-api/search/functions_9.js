var searchData=
[
  ['texttospeech',['textToSpeech',['../classrokid_1_1VoiceAI.html#a920b34e2107dfc75c542609ad6fbcb48',1,'rokid::VoiceAI']]]
];
